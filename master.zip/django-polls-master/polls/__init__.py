# -*- coding: utf-8 -*-
from __future__ import absolute_import

__version__ = '0.0.4'

default_app_config = 'polls.apps.PollsConfig'

