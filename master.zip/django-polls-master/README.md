django-polls
============

Django tutorial polls app. Forked repo for Beginning django CMS book, First Edition
